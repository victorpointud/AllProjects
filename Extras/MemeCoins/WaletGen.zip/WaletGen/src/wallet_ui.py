
#   Interfaz web para:
#	    1. Generar wallets SOL y guardarlas.
#	    2. Consultar el saldo de esas wallets.

from flask import Flask, render_template, request, redirect, url_for
from solders.keypair import Keypair
from solders.pubkey import Pubkey
from solana.rpc.api import Client as SolanaClient
import base58
import os
import shutil

app = Flask(__name__)
solana_client = SolanaClient("https://api.mainnet-beta.solana.com")


@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        num = int(request.form.get("num_wallets", 1))
        if not 1 <= num <= 50:
            return render_template("index.html", error="Please enter a number between 1 and 50.")

        if not os.path.exists("./solBackup"):
            os.makedirs("./solBackup")

        if os.path.exists("./solwallets.txt"):
            backup_num = 1
            while os.path.exists(f"solbackup/solwallets{backup_num}.txt"):
                backup_num += 1
            shutil.move("./solwallets.txt", f"solbackup/solwallets{backup_num}.txt")

        generated_wallets = []
        with open("./solwallets.txt", "a") as f:
            for _ in range(num):
                keypair = Keypair()
                address = str(keypair.pubkey())
                private_key_b58 = base58.b58encode(bytes(keypair)).decode("utf-8")
                f.write(f"{address}: {private_key_b58}\n")
                generated_wallets.append((address, private_key_b58))

        return render_template("index.html", wallets=generated_wallets, success=True)

    return render_template("index.html")


@app.route("/src/templates")
def balances():
    try:
        with open("./solwallets.txt", "r") as f:
            wallets = [line.strip().split(":") for line in f if line.strip()]
    except FileNotFoundError:
        return render_template("balance.html", error="solwallets.txt not found!")

    wallet_balances = []
    for address, _ in wallets:
        pubkey = Pubkey.from_string(address.strip())
        sol_response = solana_client.get_balance(pubkey)
        sol_balance = sol_response.value / 10**9
        wallet_balances.append((address.strip(), sol_balance))

    return render_template("balance.html", balances=wallet_balances)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5001, debug=True)