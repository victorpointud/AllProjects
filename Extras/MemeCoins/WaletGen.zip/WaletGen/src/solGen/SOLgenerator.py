
#   Script interactivo en terminal que hace lo mismo que el Flask, pero por consola:
#       1. Pide por input cuántas wallets generar (1–50).
#       2. Hace backup si ya existe solwallets.txt.
#       3. Genera wallets y las guarda igual que en Flask.
#       4. Lee solwallets.txt.
#       5. Por cada wallet, obtiene su balance usando la API de Solana.
#       6. Reintenta hasta 10 veces si hay error de conexión.


import os
import shutil
import time
from solders.keypair import Keypair
from solders.pubkey import Pubkey
from solana.rpc.api import Client as SolanaClient
import base58

solana_client = SolanaClient("https://api.mainnet-beta.solana.com")

def create_solana_wallets():
    try:
        num = int(input("How many Solana wallets to create (1-50)? "))
        if not 1 <= num <= 50:
            print("Please enter a number between 1 and 50!")
            return

        if not os.path.exists("../../solBackup"):
            os.makedirs("../../solBackup")

        if os.path.exists("../../solwallets.txt"):
            backup_num = 1
            while os.path.exists(f"solbackup/solwallets{backup_num}.txt"):
                backup_num += 1
            shutil.move("../../solwallets.txt", f"solbackup/solwallets{backup_num}.txt")
            print(f"Existing solwallets.txt moved to solbackup/solwallets{backup_num}.txt")

        with open("../../solwallets.txt", "a") as f:
            for _ in range(num):
                keypair = Keypair()
                address = str(keypair.pubkey())
                private_key_b58 = base58.b58encode(bytes(keypair)).decode("utf-8")
                f.write(f"{address}: {private_key_b58}\n")
                print(f"Solana wallet created: {address}")
        print(f"{num} Solana wallets saved to new solwallets.txt")
    except ValueError:
        print("Error: please enter a valid number!")

def check_solana_balances():
    try:
        with open("../../solwallets.txt", "r") as f:
            wallets = [line.strip().split(":") for line in f if line.strip()]
        if not wallets:
            print("solwallets.txt is empty or does not exist!")
            return

        for address, _ in wallets:
            pubkey = Pubkey.from_string(address)

            max_attempts = 10
            attempts = 0
            while attempts < max_attempts:
                try:
                    sol_response = solana_client.get_balance(pubkey)
                    sol_balance = sol_response.value / 10**9
                    print(f"Solana address: {address} | SOL: {sol_balance}")
                    break
                except Exception as e:
                    attempts += 1
                    print(f"Try #{attempts}. Error: {e} [Retrying in 0.25 seconds...]")
                    time.sleep(0.25)
            else:
                print(f"❌ Failed to fetch balance for {address} after multiple attempts.")
    except FileNotFoundError:
        print("solwallets.txt not found!")
    except Exception as e:
        print(f"Error: {e}")

def main():
    while True:
        print("\n=== Solana Menu ===")
        print("1) Create Solana wallets (1-50)")
        print("2) Check SOL balance")
        print("3) Exit")
        choice = input("Choose an option (1-3): ")

        if choice == "1":
            create_solana_wallets()
        elif choice == "2":
            check_solana_balances()
        elif choice == "3":
            print("Exiting the program...")
            break
        else:
            print("Invalid choice!")

if __name__ == "__main__":
    main()