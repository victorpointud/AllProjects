import os
import sys
import time
import threading
import platform
import subprocess
import requests
from datetime import datetime
from collections import defaultdict
from concurrent.futures import ThreadPoolExecutor, as_completed
from tqdm import tqdm

from pathlib import Path

from time import perf_counter
from random import random

CHUNK_SIZE = 50
MIN_LENGTH, MAX_LENGTH = 3, 8
MAX_THREADS = 20
MAX_TLD_THREADS = 3
MAX_DOMAIN_AGE_HOURS = 48
WHOIS_DELAY = 0.1
HTTP_TIMEOUT = 3
MAX_WHOIS_THREADS = 10
WHOIS_RATE_LIMIT_MS = 600
WHOIS_MAX_RETRIES = 5
WHOIS_BACKOFF_BASE_MS = 300


BASE_DIR = Path(__file__).resolve().parents[1]
INPUT_FILE = BASE_DIR / "domain-names.txt"
OUTPUT_DIR = BASE_DIR / "txt"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

stats = defaultdict(int)
stats_lock = threading.Lock()

WHOIS_METHOD = None
whois_lib = None

_last_whois_call = {}              # {tld: last_ts}
_rate_lock = threading.Lock()

def _throttle_whois(tld):

    with _rate_lock:
        now = perf_counter()
        last = _last_whois_call.get(tld, 0.0)
        min_gap = WHOIS_RATE_LIMIT_MS / 1000.0
        wait = last + min_gap - now
        if wait > 0:
            time.sleep(wait)
            now = perf_counter()
        _last_whois_call[tld] = now

def detect_whois_library():
    """Improved WHOIS library detection."""
    global WHOIS_METHOD, whois_lib

    print("🔍 Diagnosing WHOIS libraries...")

    try:
        import whois as imported_whois
        whois_lib = imported_whois

        if hasattr(imported_whois, 'whois'):
            try:
                test_result = imported_whois.whois('google.com')
                if hasattr(test_result, 'creation_date'):
                    WHOIS_METHOD = 'python-whois'
                    print("✅ Library in use: python-whois")
                    print(f"📊 Test successful: {type(test_result)}")
                    return imported_whois
            except Exception as e:
                print(f"⚠️  Error testing python-whois: {e}")

        if hasattr(imported_whois, 'query'):
            try:
                test_result = imported_whois.query('google.com')
                if test_result and hasattr(test_result, 'creation_date'):
                    WHOIS_METHOD = 'whois'
                    print("✅ Library in use: whois")
                    print(f"📊 Test successful: {type(test_result)}")
                    return imported_whois
            except Exception as e:
                print(f"⚠️  Error testing whois: {e}")

        print(f"❌ whois library imported, but API is not functional")
        print(f"🔧 Available methods: {[attr for attr in dir(imported_whois) if not attr.startswith('_')]}")

    except ImportError:
        print("❌ whois library is not installed")

    if platform.system() != 'Windows':
        try:
            result = subprocess.run(['whois', '--version'], capture_output=True, timeout=5)
            if result.returncode == 0 or 'whois' in result.stderr.decode().lower():
                WHOIS_METHOD = 'system'
                print("✅ Using system command: whois")
                return None
        except (subprocess.TimeoutExpired, FileNotFoundError):
            pass
    else:
        print("⚠️  System whois command is unavailable on Windows")

    print("❌ WHOIS library not found or not working!")
    print("💡 Recommendations:")
    print("   pip uninstall whois")
    print("   pip install python-whois")
    WHOIS_METHOD = 'none'
    return None


def update_stats(key, value=1):
    with stats_lock:
        stats[key] += value


def get_domain_creation_date_python_whois(domain, tld_hint=None):
    for attempt in range(1, WHOIS_MAX_RETRIES + 1):
        try:
            if tld_hint:
                _throttle_whois(tld_hint)

            w = whois_lib.whois(domain)
            if not w:
                raise RuntimeError("empty whois response")

            creation_date = getattr(w, "creation_date", None)
            if isinstance(creation_date, list):
                creation_date = creation_date[0] if creation_date else None

            if creation_date:
                return creation_date
            else:
                raise RuntimeError("no creation_date in whois response")

        except Exception as e:
            msg = str(e)
            transient = ("Connection reset by peer" in msg
                         or "timed out" in msg
                         or "timeout" in msg
                         or "EOF occurred" in msg
                         or "empty whois response" in msg
                         or "no creation_date" in msg)

            if attempt >= WHOIS_MAX_RETRIES or not transient:
                print(f"⚠️  python-whois error for {domain}: {e}")
                return None

            backoff = (WHOIS_BACKOFF_BASE_MS * (2 ** (attempt - 1))) / 1000.0
            backoff *= (0.75 + 0.5 * random())
            time.sleep(backoff)


def get_domain_creation_date_whois(domain):
    """Retrieves the domain creation date using the 'whois' library."""
    try:
        w = whois_lib.query(domain)
        if w and hasattr(w, 'creation_date'):
            return w.creation_date
        return None
    except Exception as e:
        print(f"⚠️  whois error for {domain}: {e}")
        return None


def get_domain_creation_date_system(domain):
    """Retrieves the domain creation date using the system 'whois' command."""
    try:
        result = subprocess.run(['whois', domain], capture_output=True, text=True, timeout=10)
        if result.returncode != 0:
            return None

        output = result.stdout.lower()

        creation_patterns = [
            'creation date:',
            'created:',
            'registered:',
            'registration time:',
            'domain_dateregistered:',
            'created on:',
            'registered on:'
        ]

        for line in output.split('\n'):
            line = line.strip()
            for pattern in creation_patterns:
                if pattern in line:

                    date_part = line.split(pattern)[1].strip()

                    date_part = date_part.split()[0]

                    date_formats = [
                        '%Y-%m-%d',
                        '%Y-%m-%dT%H:%M:%S',
                        '%Y-%m-%dT%H:%M:%SZ',
                        '%Y-%m-%d %H:%M:%S',
                        '%d-%m-%Y',
                        '%d.%m.%Y',
                        '%Y/%m/%d'
                    ]

                    for fmt in date_formats:
                        try:
                            return datetime.strptime(date_part, fmt)
                        except ValueError:
                            continue

        return None
    except (subprocess.TimeoutExpired, FileNotFoundError, Exception) as e:
        print(f"⚠️  System whois error for {domain}: {e}")
        return None


def check_domain_age(domain):

    if WHOIS_METHOD == 'none':
        print(f"⚠️  WHOIS unavailable, assuming {domain} is new")
        update_stats('whois_unavailable')
        return True

    creation_date = None

    try:
        if WHOIS_METHOD == 'python-whois':
            creation_date = get_domain_creation_date_python_whois(domain)
        elif WHOIS_METHOD == 'whois':
            creation_date = get_domain_creation_date_whois(domain)
        elif WHOIS_METHOD == 'system':
            creation_date = get_domain_creation_date_system(domain)
    except Exception as e:
        print(f"⚠️  Unexpected WHOIS error for {domain}: {e}")
        update_stats('whois_errors')
        return False

    if not creation_date:
        print(f"⚠️  Failed to retrieve creation date for {domain}")
        update_stats('whois_no_date')
        return False

    if hasattr(creation_date, 'tzinfo') and creation_date.tzinfo is not None:
        creation_date = creation_date.replace(tzinfo=None)

    now = datetime.now()
    time_diff = now - creation_date
    hours_diff = time_diff.total_seconds() / 3600

    is_new = hours_diff <= MAX_DOMAIN_AGE_HOURS

    if is_new:
        print(f"✅ {domain} - new domain ({hours_diff:.1f} hours)")
        update_stats('new_domains')
    else:
        print(f"❌ {domain} - old domain ({hours_diff:.1f} hours)")
        update_stats('old_domains')

    return is_new


def check_https_website(domain, stop_event):
    if stop_event.is_set():
        update_stats('http_cancelled')
        return domain, False

    url = f"https://{domain}"
    headers = {
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
                      "(KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
    }
    try:
        resp = requests.head(url, timeout=HTTP_TIMEOUT, allow_redirects=True, headers=headers)
        if resp.status_code >= 400:
            resp = requests.get(url, timeout=HTTP_TIMEOUT, allow_redirects=True, headers=headers, stream=True)
        is_working = resp.status_code < 400
        update_stats('working_sites' if is_working else 'non_working_sites')
        return domain, is_working
    except requests.RequestException:
        update_stats('http_errors')
        return domain, False


def filter_new_domains(domains, tld):
    print(f"🔍 Filtering .{tld} domains by age (parallel, {MAX_WHOIS_THREADS} threads)...")
    new_domains = []

    def check_one(domain):
        cd = get_domain_creation_date_python_whois(domain, tld_hint=tld)
        if not cd:
            update_stats('whois_no_date')
            return None

        if hasattr(cd, 'tzinfo') and cd.tzinfo is not None:
            cd = cd.replace(tzinfo=None)
        hours = (datetime.now() - cd).total_seconds() / 3600.0
        if hours <= MAX_DOMAIN_AGE_HOURS:
            update_stats('new_domains')
            return domain
        else:
            update_stats('old_domains')
            return None

    with ThreadPoolExecutor(max_workers=MAX_WHOIS_THREADS) as ex:
        futures = [ex.submit(check_one, d) for d in domains]
        for fut in tqdm(as_completed(futures), total=len(futures), desc=f"WHOIS .{tld}"):
            pass

    for fut in futures:
        dom = fut.result()
        if dom:
            new_domains.append(dom)

    print(f"📊 Out of {len(domains)} .{tld} domains, new ones: {len(new_domains)}")
    return new_domains

def check_websites_for_tld(domains, tld):

    working_domains = []
    stop_event = threading.Event()

    print(f"🌐 Multi-threaded website check for .{tld} ({len(domains)} domains)")
    print(f"🎯 Goal: find {CHUNK_SIZE} working sites for .{tld}")

    with ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
        future_to_domain = {
            executor.submit(check_https_website, domain, stop_event): domain
            for domain in domains
        }

        completed_tasks = 0
        cancelled_tasks = 0

        with tqdm(total=len(domains), desc=f"HTTP .{tld}") as pbar:
            for future in as_completed(future_to_domain):
                if stop_event.is_set():
                    for remaining_future in future_to_domain:
                        if not remaining_future.done():
                            remaining_future.cancel()
                            cancelled_tasks += 1
                    break

                domain, is_working = future.result()
                completed_tasks += 1
                pbar.update(1)

                if is_working:
                    working_domains.append(domain)
                    print(f"🌐 {domain} - site is working ({len(working_domains)}/{CHUNK_SIZE} for .{tld})")

                    if len(working_domains) >= CHUNK_SIZE:
                        print(f"🎯 Target of {CHUNK_SIZE} working sites for .{tld} reached! Stopping this TLD check...")
                        stop_event.set()
                        break
                else:
                    print(f"🚫 {domain} - site is not working")

        for future in future_to_domain:
            if not future.done():
                future.cancel()
                cancelled_tasks += 1

    print(f"📈 Check summary for .{tld}:")
    print(f"   - Tasks completed: {completed_tasks}")
    print(f"   - Tasks cancelled: {cancelled_tasks}")
    print(f"   - Working sites found: {len(working_domains)}")

    return working_domains


def save_chunk_to_txt(domains_chunk, tld):

    date_str = datetime.now().strftime("%d%m%Y")
    file_name = f"{len(domains_chunk)}{tld.upper()}{date_str}.txt"
    file_path = OUTPUT_DIR / file_name

    try:
        with open(file_path, "w", encoding="utf-8") as f:
            for domain in domains_chunk:
                f.write(domain + "\n")

        print(f"💾 Saved {len(domains_chunk)} .{tld} domains to file {file_path.name}")
        update_stats('saved_files')
        update_stats('saved_domains', len(domains_chunk))
        update_stats(f'saved_{tld}', len(domains_chunk))
    except IOError as e:
        print(f"❌ Error saving file {file_path.name}: {e}")
        update_stats('save_errors')


def process_single_tld(tld, domains):

    tld_stats = {
        'tld': tld,
        'total_domains': len(domains),
        'new_domains': 0,
        'working_sites': 0,
        'processing_time': 0,
        'file_created': False
    }

    print(f"\n🚀 Independent processing of TLD .{tld} ({len(domains)} domains)")
    tld_start_time = time.time()
    new_domains = filter_new_domains(domains, tld)
    tld_stats['new_domains'] = len(new_domains)

    if not new_domains:
        print(f"❌ No new domains found in .{tld}")
        tld_stats['processing_time'] = time.time() - tld_start_time
        return tld_stats

    working_domains = check_websites_for_tld(new_domains, tld)
    tld_stats['working_sites'] = len(working_domains)

    if working_domains:
        save_chunk_to_txt(working_domains, tld)
        tld_stats['file_created'] = True
        tld_end_time = time.time()
        processing_time = tld_end_time - tld_start_time
        tld_stats['processing_time'] = processing_time
        print(f"✅ Processing .{tld} completed in {processing_time:.1f}s: {len(working_domains)} working sites")
    else:
        print(f"❌ No working sites found in .{tld}")
        tld_stats['processing_time'] = time.time() - tld_start_time

    return tld_stats


def process_all_tlds_parallel(tld_domains):

    all_tld_stats = []

    print(f"\n🔥 Starting parallel processing of {len(tld_domains)} TLDs")
    print(f"📊 Maximum parallel TLDs: {MAX_TLD_THREADS}")

    with ThreadPoolExecutor(max_workers=MAX_TLD_THREADS) as executor:

        future_to_tld = {
            executor.submit(process_single_tld, tld, domains): tld
            for tld, domains in tld_domains.items()
        }

        for future in as_completed(future_to_tld):
            tld = future_to_tld[future]
            try:
                tld_stats = future.result()
                all_tld_stats.append(tld_stats)
                print(f"🏁 Finished processing .{tld}")
            except Exception as e:
                print(f"❌ Error processing .{tld}: {e}")

    return all_tld_stats


def print_final_statistics(tld_stats_list):
    global stats

    print(f"\n📊 FINAL STATISTICS:")

    total_zones = len(tld_stats_list)
    successful_zones = sum(1 for stat_item in tld_stats_list if stat_item['file_created'])
    total_files = sum(1 for stat_item in tld_stats_list if stat_item['file_created'])
    total_saved_domains = sum(stat_item['working_sites'] for stat_item in tld_stats_list)

    print(f"   🌐 TLD Processing:")
    print(f"      - Total TLDs: {total_zones}")
    print(f"      - Successfully processed: {successful_zones}")
    print(f"      - Files created: {total_files}")
    print(f"      - Domains saved: {total_saved_domains}")

    print(f"   🔍 WHOIS checks:")
    print(f"      - New domains: {stats['new_domains']}")
    print(f"      - Old domains: {stats['old_domains']}")
    print(f"      - WHOIS unavailable: {stats['whois_unavailable']}")
    print(f"      - No creation date: {stats['whois_no_date']}")
    print(f"      - WHOIS errors: {stats['whois_errors']}")

    print(f"   🌐 HTTP checks:")
    print(f"      - Working websites: {stats['working_sites']}")
    print(f"      - Non-working websites: {stats['non_working_sites']}")
    print(f"      - HTTP errors: {stats['http_errors']}")
    print(f"      - Tasks cancelled: {stats['http_cancelled']}")

    print(f"\n📋 DETAILED TLD STATISTICS:")
    successful_stats = [s for s in tld_stats_list if s['file_created']]
    if successful_stats:
        print(f"   ✅ Successfully processed TLDs:")
        for stat_item in sorted(successful_stats, key=lambda x: x['working_sites'], reverse=True):
            print(f"      .{stat_item['tld']}: {stat_item['working_sites']} sites in {stat_item['processing_time']:.1f}s")

    failed_stats = [s for s in tld_stats_list if not s['file_created']]
    if failed_stats:
        print(f"   ❌ TLDs with no results:")
        for stat_item in failed_stats:
            print(f"      .{stat_item['tld']}: {stat_item['new_domains']} new domains, 0 working sites")


def validate_input_file():

    if not os.path.exists(INPUT_FILE):
        print(f"❌ File {INPUT_FILE} not found!")
        return False

    if not os.access(INPUT_FILE, os.R_OK):
        print(f"❌ No read permissions for file {INPUT_FILE}!")
        return False

    return True


def main():

    print("🚀 Launching script v9.1 - Fixed WHOIS diagnostics")
    print(f"💻 Operating System: {platform.system()}")


    detect_whois_library()

    print(f"📊 Parameters:")
    print(f"   - File size per zone: {CHUNK_SIZE} domains")
    print(f"   - Maximum age: {MAX_DOMAIN_AGE_HOURS} hours")
    print(f"   - Input file: {INPUT_FILE}")
    print(f"   - HTTP threads: {MAX_THREADS}")
    print(f"   - Parallel TLDs: {MAX_TLD_THREADS}")
    print(f"   - HTTP timeout: {HTTP_TIMEOUT} seconds")
    print(f"   - WHOIS delay: {WHOIS_DELAY} seconds")
    print(f"   - WHOIS method: {WHOIS_METHOD}")
    print("🔥 FIXES in v9.1:")
    print("   ✅ Improved WHOIS library diagnostics")
    print("   ✅ Proper operation of python-whois on Windows")
    print("   ✅ Disabling system whois command on Windows")
    print("   ✅ Enhanced error handling")
    print("-" * 70)


    if not validate_input_file():
        return 1

    tld_domains = {}
    total_domains = 0
    filtered_domains = 0

    try:
        with open(INPUT_FILE, "r", encoding="utf-8") as file:
            for line_num, line in enumerate(file, 1):
                domain = line.strip()
                if not domain:
                    continue

                total_domains += 1

                parts = domain.split('.')
                if len(parts) < 2:
                    print(f"⚠️  Line {line_num}: invalid domain format '{domain}'")
                    continue

                domain_name, tld = parts[0], parts[-1]

                if any(char.isdigit() for char in domain_name):
                    continue

                if not (MIN_LENGTH <= len(domain_name) <= MAX_LENGTH):
                    continue

                if tld not in tld_domains:
                    tld_domains[tld] = []

                tld_domains[tld].append(domain)
                filtered_domains += 1

    except IOError as e:
        print(f"❌ Error reading file {INPUT_FILE}: {e}")
        return 1

    print(f"📁 Loading statistics:")
    print(f"   - Total domains in file: {total_domains}")
    print(f"   - Passed filtering: {filtered_domains}")
    print(f"   - Domain zones: {len(tld_domains)}")
    print()

    print(f"📋 Domains loaded per zone:")
    for tld, domains in sorted(tld_domains.items(), key=lambda x: len(x[1]), reverse=True):
        print(f"   .{tld}: {len(domains)} domains")

    start_time = datetime.now()
    tld_stats_list = process_all_tlds_parallel(tld_domains)
    end_time = datetime.now()
    processing_time = end_time - start_time

    print_final_statistics(tld_stats_list)

    print(f"\n✅ Domain check complete!")
    print(f"⏱️  Total execution time: {processing_time}")
    print(f"📁 Results saved in files: [count][TLD][date].txt")
    print(f"🔥 Each domain zone processed independently!")

    return 0


if __name__ == "__main__":
    sys.exit(main())

