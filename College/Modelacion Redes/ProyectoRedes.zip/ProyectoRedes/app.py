
from flask import Flask, render_template, request
from heapq import heappush, heappop

app = Flask(__name__)

CALLES   = range(50, 56)  
CARRERAS = range(10, 16)  

JAVIER   = (54, 14) 
ANDREINA = (52, 13) 

DESTINOS = {
    "The Darkness (C50 x Cr14)": (50, 14),
    "Bar La Pasión (C54 x Cr11)": (54, 11),
    "Cervecería Mi Rolita (C50 x Cr12)": (50, 12),
}

def vecinos(nodo):
    c, r = nodo
   
    for dc in (-1, 1):
        nc = c + dc
        if nc in CALLES:
            w = 7 if r in (11, 12, 13) else 5
            yield (nc, r), w
   
    for dr in (-1, 1):
        nr = r + dr
        if nr in CARRERAS:
            w = 10 if c == 51 else 5
            yield (c, nr), w

def dijkstra(origen, destino=None):
    INF = 10**9
    dist = { (c,r): INF for c in CALLES for r in CARRERAS }
    pred = { (c,r): None for c in CALLES for r in CARRERAS }
    dist[origen] = 0
    pq = [(0, origen)]
    vis = set()
    while pq:
        d,u = heappop(pq)
        if u in vis:
            continue
        vis.add(u)
        if destino is not None and u == destino:
            break
        for v,w in vecinos(u):
            if v in vis:
                continue
            nd = d + w
            if nd < dist[v]:
                dist[v] = nd
                pred[v] = u
                heappush(pq, (nd, v))
    return dist, pred

def reconstruir(pred, s, t):
    ruta = []
    u = t
    while u is not None:
        ruta.append(u)
        if u == s:
            break
        u = pred[u]
    return list(reversed(ruta))

def instrucciones(ruta):
    pasos = []
    for (c1,r1),(c2,r2) in zip(ruta, ruta[1:]):
        if c2 != c1: 
            dirn = "Norte" if c2 > c1 else "Sur"
            pasos.append(f"Desde Calle {c1} con Carrera {r1}: avance 1 cuadra hacia {dirn} por Carrera {r1} hasta Calle {c2} con Carrera {r2}.")
        else:        
            dirn = "Este" if r2 < r1 else "Oeste"  
            pasos.append(f"Desde Calle {c1} con Carrera {r1}: avance 1 cuadra hacia {dirn} por Calle {c1} hasta Calle {c2} con Carrera {r2}.")
    return pasos

@app.route("/", methods=["GET", "POST"])
def index():
    selected_key = None
    resultado = None

    if request.method == "POST":
        selected_key = request.form.get("destino")
        destino = DESTINOS.get(selected_key)

        if destino:

            dj, pj = dijkstra(JAVIER, destino)
            ruta_j = reconstruir(pj, JAVIER, destino)
            t_j    = dj[destino]
            pasos_j = instrucciones(ruta_j)

            da, pa = dijkstra(ANDREINA, destino)
            ruta_a = reconstruir(pa, ANDREINA, destino)
            t_a    = da[destino]
            pasos_a = instrucciones(ruta_a)


            if t_j == t_a:
                sync_msg = "Salen al mismo tiempo."
            elif t_j < t_a:
                sync_msg = f"Javier debe salir {t_a - t_j} min DESPUÉS que Andreína."
            else:
                sync_msg = f"Andreína debe salir {t_j - t_a} min DESPUÉS que Javier."

            resultado = {
                "destino_nombre": selected_key,
                "destino_coord": destino,
                "javier": {
                    "origen": JAVIER,
                    "tiempo": t_j,
                    "ruta": ruta_j,
                    "pasos": pasos_j
                },
                "andreina": {
                    "origen": ANDREINA,
                    "tiempo": t_a,
                    "ruta": ruta_a,
                    "pasos": pasos_a
                },
                "sincronizacion": sync_msg
            }

    return render_template(
        "index.html",
        destinos=list(DESTINOS.keys()),
        selected_key=selected_key,
        resultado=resultado
    )

if __name__ == "__main__":
    app.run(debug=True)